/* ─────────────────────────────────────────────────────────
   ISL Translator — Frontend JavaScript
   Handles: voice recognition, AJAX translate calls,
            result rendering, letter animation, history
   ───────────────────────────────────────────────────────── */

'use strict';

// ── State ────────────────────────────────────────────────────
let currentResults   = [];
let currentIndex     = 0;
let autoPlayTimer    = null;
let isAutoPlaying    = false;
let isRecording      = false;
let recognition      = null;
let lastVoiceText    = '';
let history          = [];

// ── DOM refs (resolved after DOMContentLoaded) ───────────────
const $ = id => document.getElementById(id);

// ═══════════════════════════════════════════════════════════════
//  MODE TOGGLE (Text ↔ Voice)
// ═══════════════════════════════════════════════════════════════
function setMode(mode) {
  $('textMode').classList.toggle('hidden', mode !== 'text');
  $('voiceMode').classList.toggle('hidden', mode !== 'voice');
  $('modeText').classList.toggle('active', mode === 'text');
  $('modeVoice').classList.toggle('active', mode === 'voice');
}

// ═══════════════════════════════════════════════════════════════
//  TEXT INPUT — helpers
// ═══════════════════════════════════════════════════════════════
function fillText(phrase) {
  const ta = $('textInput');
  ta.value = phrase;
  updateCharCounter();
  ta.focus();
}

function updateCharCounter() {
  const val = $('textInput').value;
  $('charCounter').textContent = `${val.length} / 500`;
}

// ═══════════════════════════════════════════════════════════════
//  TRANSLATE (text input)
// ═══════════════════════════════════════════════════════════════
async function translateText() {
  const text = $('textInput').value.trim();
  if (!text) { flashInput(); return; }
  await doTranslate(text);
}

async function translateFromVoice() {
  if (!lastVoiceText) return;
  await doTranslate(lastVoiceText);
}

async function doTranslate(text) {
  showLoading();
  stopAutoPlay();

  try {
    const resp = await fetch('/translate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    });
    const data = await resp.json();

    if (data.error && (!data.results || data.results.length === 0)) {
      showError(data.error);
      return;
    }

    currentResults = data.results || [];
    currentIndex   = 0;
    renderResults(text);
    addToHistory(text, currentResults.length);

  } catch (err) {
    showError('Network error — please check your connection.');
    console.error(err);
  }
}

// ═══════════════════════════════════════════════════════════════
//  RESULT RENDERING
// ═══════════════════════════════════════════════════════════════
function renderResults(inputText) {
  if (!currentResults.length) { showError('No ISL signs found for this input.'); return; }

  // Meta
  $('resultMeta').textContent = `${currentResults.length} sign${currentResults.length > 1 ? 's' : ''} for "${inputText}"`;

  // Show panel
  $('emptyState').classList.add('hidden');
  $('loadingState').classList.add('hidden');
  $('errorState').classList.add('hidden');
  $('signsDisplay').classList.remove('hidden');

  renderCurrentSign();
  buildThumbStrip();
  updateNav();
}

function renderCurrentSign() {
  const item = currentResults[currentIndex];
  if (!item) return;

  const img   = $('signImage');
  const label = $('signLabel');
  const badge = $('signTypeBadge');

  img.src = item.src + '?t=' + Date.now(); // bust cache for GIF restart
  img.alt = item.label;
  label.textContent = item.label;

  if (item.type === 'gif') {
    badge.textContent = 'Phrase GIF';
    badge.className   = 'sign-type-badge';
  } else {
    badge.textContent = 'Hand Sign — ' + item.label;
    badge.className   = 'sign-type-badge letter-badge';
  }

  // Sync thumbnails
  document.querySelectorAll('.thumb').forEach((t, i) => {
    t.classList.toggle('active', i === currentIndex);
    if (i === currentIndex) t.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
  });

  $('navCounter').textContent = `${currentIndex + 1} / ${currentResults.length}`;
}

function buildThumbStrip() {
  const strip = $('thumbStrip');
  strip.innerHTML = '';
  currentResults.forEach((item, i) => {
    const img = document.createElement('img');
    img.src   = item.src;
    img.alt   = item.label;
    img.title = item.label;
    img.className = 'thumb' + (i === currentIndex ? ' active' : '');
    img.addEventListener('click', () => { currentIndex = i; renderCurrentSign(); });
    strip.appendChild(img);
  });
}

function updateNav() {
  const show = currentResults.length > 1;
  $('signsNav').style.display = show ? 'flex' : 'none';
  $('prevBtn').disabled = currentIndex === 0;
  $('nextBtn').disabled = currentIndex === currentResults.length - 1;
}

// ═══════════════════════════════════════════════════════════════
//  NAVIGATION
// ═══════════════════════════════════════════════════════════════
function navigate(dir) {
  const next = currentIndex + dir;
  if (next < 0 || next >= currentResults.length) return;
  currentIndex = next;
  renderCurrentSign();
  updateNav();
}

// ═══════════════════════════════════════════════════════════════
//  AUTO-PLAY
// ═══════════════════════════════════════════════════════════════
function toggleAutoPlay() {
  if (isAutoPlaying) stopAutoPlay();
  else               startAutoPlay();
}

function startAutoPlay() {
  if (!currentResults.length) return;
  isAutoPlaying = true;
  $('autoPlayBtn').classList.add('active');
  $('autoPlayBtn').innerHTML = `
    <svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>
    Pause
  `;
  scheduleNext();
}

function stopAutoPlay() {
  isAutoPlaying = false;
  clearTimeout(autoPlayTimer);
  const btn = $('autoPlayBtn');
  if (btn) {
    btn.classList.remove('active');
    btn.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none"><polygon points="5,3 19,12 5,21" fill="currentColor"/></svg>
      Auto-Play
    `;
  }
}

function scheduleNext() {
  if (!isAutoPlaying) return;
  const item = currentResults[currentIndex];
  // GIFs get more time; letter images get 900ms
  const delay = item.type === 'gif' ? 3000 : 900;
  autoPlayTimer = setTimeout(() => {
    if (currentIndex < currentResults.length - 1) {
      currentIndex++;
      renderCurrentSign();
      updateNav();
      scheduleNext();
    } else {
      stopAutoPlay();
    }
  }, delay);
}

function restartPlay() {
  stopAutoPlay();
  currentIndex = 0;
  renderCurrentSign();
  updateNav();
  startAutoPlay();
}

// ═══════════════════════════════════════════════════════════════
//  UI STATE HELPERS
// ═══════════════════════════════════════════════════════════════
function showLoading() {
  $('emptyState').classList.add('hidden');
  $('signsDisplay').classList.add('hidden');
  $('errorState').classList.add('hidden');
  $('loadingState').classList.remove('hidden');
}

function showError(msg) {
  $('emptyState').classList.add('hidden');
  $('signsDisplay').classList.add('hidden');
  $('loadingState').classList.add('hidden');
  $('errorState').classList.remove('hidden');
  $('errorMsg').textContent = msg;
}

function flashInput() {
  const ta = $('textInput');
  ta.style.borderColor = 'var(--clr-error)';
  ta.style.boxShadow   = '0 0 0 3px rgba(248,113,113,0.2)';
  setTimeout(() => { ta.style.borderColor = ''; ta.style.boxShadow = ''; }, 1200);
  ta.focus();
}

// ═══════════════════════════════════════════════════════════════
//  HISTORY
// ═══════════════════════════════════════════════════════════════
function addToHistory(text, count) {
  // Avoid duplicates at top
  if (history.length && history[0].text === text) return;
  history.unshift({ text, count });
  if (history.length > 20) history.pop();
  renderHistory();
}

function renderHistory() {
  const list = $('historyList');
  if (!history.length) {
    list.innerHTML = '<p class="history-empty">No translations yet.</p>';
    return;
  }
  list.innerHTML = history.map((h, i) => `
    <div class="history-item" onclick="replayHistory(${i})" title="${escHtml(h.text)}">
      <div class="history-icon">
        <svg viewBox="0 0 24 24" fill="none"><path d="M5 12h14M12 5l7 7-7 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </div>
      <span class="history-item-text">${escHtml(h.text)}</span>
      <span class="history-item-count">${h.count} sign${h.count !== 1 ? 's' : ''}</span>
    </div>
  `).join('');
}

function replayHistory(i) {
  const h = history[i];
  if (!h) return;
  $('textInput').value = h.text;
  updateCharCounter();
  setMode('text');
  doTranslate(h.text);
}

function clearHistory() {
  history = [];
  renderHistory();
}

function escHtml(s) {
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ═══════════════════════════════════════════════════════════════
//  VOICE RECOGNITION (Web Speech API)
// ═══════════════════════════════════════════════════════════════
function toggleVoice() {
  if (isRecording) stopVoice();
  else             startVoice();
}

function startVoice() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    alert('Sorry — your browser does not support voice recognition.\nPlease use Chrome or Edge.');
    return;
  }

  recognition = new SpeechRecognition();
  recognition.continuous    = false;
  recognition.interimResults = true;
  recognition.lang          = 'en-IN';
  recognition.maxAlternatives = 1;

  recognition.onstart = () => {
    isRecording = true;
    $('micBtn').classList.add('recording');
    $('micHint').textContent = '🔴 Listening… speak now';
    setBadge('Listening…', true);
    $('voiceTranscriptBox').classList.add('hidden');
  };

  recognition.onresult = (event) => {
    let interim = '';
    let final   = '';
    for (let i = event.resultIndex; i < event.results.length; i++) {
      if (event.results[i].isFinal) final   += event.results[i][0].transcript;
      else                          interim += event.results[i][0].transcript;
    }
    const display = (final || interim).trim();
    if (display) {
      $('voiceTranscript').textContent = display;
      $('voiceTranscriptBox').classList.remove('hidden');
      lastVoiceText = display;
    }
  };

  recognition.onend = () => {
    isRecording = false;
    $('micBtn').classList.remove('recording');
    $('micHint').textContent = lastVoiceText
      ? '✅ Speech captured — click Translate!'
      : 'Click the microphone to start speaking';
    setBadge('Ready', false);
    if (lastVoiceText) {
      // Auto-translate after voice stops
      doTranslate(lastVoiceText);
    }
  };

  recognition.onerror = (event) => {
    isRecording = false;
    $('micBtn').classList.remove('recording');
    setBadge('Ready', false);
    let msg = 'Voice error: ' + event.error;
    if (event.error === 'not-allowed')  msg = '🎙️ Microphone access denied. Please allow mic access in your browser.';
    if (event.error === 'no-speech')    msg = 'No speech detected. Try again.';
    if (event.error === 'network')      msg = 'Network error during voice recognition.';
    $('micHint').textContent = msg;
  };

  recognition.start();
}

function stopVoice() {
  if (recognition) recognition.stop();
}

function setBadge(label, active) {
  const badge = $('speechStatus');
  $('speechStatus').querySelector('.badge-label').textContent = label;
  badge.classList.toggle('recording', active);
}

// ═══════════════════════════════════════════════════════════════
//  KEYBOARD SHORTCUTS
// ═══════════════════════════════════════════════════════════════
document.addEventListener('keydown', e => {
  // Ctrl+Enter  → translate
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
    e.preventDefault();
    translateText();
  }
  // ArrowLeft / ArrowRight → navigate signs
  if ($('signsDisplay') && !$('signsDisplay').classList.contains('hidden')) {
    if (e.key === 'ArrowLeft')  navigate(-1);
    if (e.key === 'ArrowRight') navigate(1);
    if (e.key === ' ') { e.preventDefault(); toggleAutoPlay(); }
  }
});

// ═══════════════════════════════════════════════════════════════
//  INIT
// ═══════════════════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', () => {
  // Char counter
  $('textInput').addEventListener('input', updateCharCounter);

  // Enter key in textarea
  $('textInput').addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      translateText();
    }
  });

  // Init history
  renderHistory();
  console.log('%c ISL Translator ready 🤟', 'color:#7C3AED;font-weight:700;font-size:14px');
});
