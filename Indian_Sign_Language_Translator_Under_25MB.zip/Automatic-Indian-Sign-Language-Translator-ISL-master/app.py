import os
import string
from flask import Flask, render_template, request, jsonify, send_from_directory

app = Flask(__name__)

# Base directory of this file
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ── ISL phrase dictionary (same list as main2.py) ────────────────────────────
ISL_GIF_LIST = [
    'any questions', 'are you angry', 'are you busy', 'are you hungry',
    'are you sick', 'be careful', 'can we meet tomorrow',
    'did you book tickets', 'did you finish homework', 'do you go to office',
    'do you have money', 'do you want something to drink',
    'do you want tea or coffee', 'do you watch tv', 'dont worry',
    'flower is beautiful', 'good afternoon', 'good evening', 'good morning',
    'good night', 'good question', 'had your lunch', 'happy journey',
    'hello what is your name', 'how many people are there in your family',
    'i am a clerk', 'i am bore doing nothing', 'i am fine', 'i am sorry',
    'i am thinking', 'i am tired', 'i dont understand anything',
    'i go to a theatre', 'i love to shop',
    'i had to say something but i forgot', 'i have headache',
    'i like pink colour', 'i live in nagpur', 'lets go for lunch',
    'my mother is a homemaker', 'my name is john', 'nice to meet you',
    'no smoking please', 'open the door', 'please call me later',
    'please clean the room', 'please give me your pen',
    'please use dustbin dont throw garbage', 'please wait for sometime',
    'shall i help you', 'shall we go together tommorow',
    'sign language interpreter', 'sit down', 'stand up', 'take care',
    'there was traffic jam', 'wait i am thinking', 'what are you doing',
    'what is the problem', 'what is todays date', 'what is your father do',
    'what is your job', 'what is your mobile number', 'what is your name',
    'whats up', 'when is your interview', 'when we will go',
    'where do you stay', 'where is the bathroom', 'where is the police station',
    'you are wrong',
    # single words / places / things
    'address', 'agra', 'ahemdabad', 'all', 'april', 'assam', 'august',
    'australia', 'badoda', 'banana', 'banaras', 'banglore', 'bihar',
    'bridge', 'cat', 'chandigarh', 'chennai', 'christmas', 'church',
    'clinic', 'coconut', 'crocodile', 'dasara', 'deaf', 'december', 'deer',
    'delhi', 'dollar', 'duck', 'febuary', 'friday', 'fruits', 'glass',
    'grapes', 'gujrat', 'hello', 'hindu', 'hyderabad', 'india', 'january',
    'jesus', 'job', 'july', 'karnataka', 'kerala', 'krishna', 'litre',
    'mango', 'may', 'mile', 'monday', 'mumbai', 'museum', 'muslim',
    'nagpur', 'october', 'orange', 'pakistan', 'pass', 'police station',
    'post office', 'pune', 'punjab', 'rajasthan', 'ram', 'restaurant',
    'saturday', 'september', 'shop', 'sleep', 'southafrica', 'story',
    'sunday', 'tamil nadu', 'temperature', 'temple', 'thursday', 'toilet',
    'tomato', 'town', 'tuesday', 'usa', 'village', 'voice', 'wednesday',
    'weight',
]

# Build a set for O(1) look-up (all lowercase)
ISL_GIF_SET = set(ISL_GIF_LIST)

LETTERS = set('abcdefghijklmnopqrstuvwxyz')

# ── Helper: discover which GIFs actually exist on disk ───────────────────────
def get_available_gifs():
    gif_dir = os.path.join(BASE_DIR, 'ISL_Gifs')
    available = set()
    if os.path.isdir(gif_dir):
        for f in os.listdir(gif_dir):
            if f.lower().endswith('.gif'):
                available.add(os.path.splitext(f)[0].lower())
    return available

AVAILABLE_GIFS = get_available_gifs()

# ── Translation logic ─────────────────────────────────────────────────────────
def translate_text(text: str):
    """
    Returns a list of result objects:
      { "type": "gif",    "src": "/gifs/<name>.gif",  "label": "<phrase>" }
      { "type": "letter", "src": "/letters/<c>.jpg",   "label": "<char>"  }
    """
    # Normalise
    text = text.lower().strip()
    for ch in string.punctuation:
        text = text.replace(ch, '')
    text = ' '.join(text.split())   # collapse whitespace

    if not text:
        return []

    results = []

    # 1. Try full phrase first
    if text in ISL_GIF_SET and text in AVAILABLE_GIFS:
        results.append({
            'type': 'gif',
            'src': f'/gifs/{text}.gif',
            'label': text
        })
        return results

    # 2. Word-by-word: for each word try gif, else spell it out
    words = text.split()
    for word in words:
        if word in ISL_GIF_SET and word in AVAILABLE_GIFS:
            results.append({
                'type': 'gif',
                'src': f'/gifs/{word}.gif',
                'label': word
            })
        else:
            # spell letter by letter
            for ch in word:
                if ch in LETTERS:
                    results.append({
                        'type': 'letter',
                        'src': f'/letters/{ch}.jpg',
                        'label': ch.upper()
                    })

    return results


# ── Routes ────────────────────────────────────────────────────────────────────
@app.route('/')
def index():
    return render_template('index.html')


@app.route('/translate', methods=['POST'])
def translate():
    data = request.get_json(force=True)
    text = data.get('text', '').strip()

    if not text:
        return jsonify({'error': 'No text provided', 'results': []}), 400

    results = translate_text(text)

    if not results:
        return jsonify({'error': 'Could not find any signs for that input.', 'results': []})

    return jsonify({'results': results, 'input': text})


@app.route('/gifs/<path:filename>')
def serve_gif(filename):
    gif_dir = os.path.join(BASE_DIR, 'ISL_Gifs')
    return send_from_directory(gif_dir, filename)


@app.route('/letters/<path:filename>')
def serve_letter(filename):
    letter_dir = os.path.join(BASE_DIR, 'letters')
    return send_from_directory(letter_dir, filename)


@app.route('/phrases')
def get_phrases():
    """Return the list of known ISL phrases (for autocomplete hints)."""
    return jsonify({'phrases': sorted(ISL_GIF_LIST)})


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == '__main__':
    app.run(debug=True, port=5000)
